from peewee import SqliteDatabase

db = SqliteDatabase('contas_clientes.db')
